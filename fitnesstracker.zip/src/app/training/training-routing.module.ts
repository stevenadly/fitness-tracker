import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrainingComponent } from './training.component';
import { AuthGuard } from '../auth/auth-gaurd.model';


let traingingRoutes :Routes=[
    // , canActivate: [AuthGuard]
    { path: '', component: TrainingComponent  , canActivate: [AuthGuard] }

]
@NgModule({
  imports:[RouterModule.forChild(traingingRoutes)],
  exports:[RouterModule],
  // providers:[AuthGuard]

})
export class TraingRouting{

}
