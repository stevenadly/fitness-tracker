export interface User{
    // how the user would look like all rtthe application
    email :string,
    userId: string
}