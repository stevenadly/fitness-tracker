// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyDQ6Lv7N563cQmyYsM0ZRZVhU4ZGSemPzE",
    authDomain: "fitness-tracker-a32a5.firebaseapp.com",
    databaseURL: "https://fitness-tracker-a32a5.firebaseio.com",
    projectId: "fitness-tracker-a32a5",
    storageBucket: "fitness-tracker-a32a5.appspot.com",
    messagingSenderId: "1067208300525",
    appId: "1:1067208300525:web:39a89b0c5555dd141a39e4",
    measurementId: "G-3RSC25YFHN"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
