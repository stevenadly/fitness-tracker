export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyDQ6Lv7N563cQmyYsM0ZRZVhU4ZGSemPzE",
    authDomain: "fitness-tracker-a32a5.firebaseapp.com",
    databaseURL: "https://fitness-tracker-a32a5.firebaseio.com",
    projectId: "fitness-tracker-a32a5",
    storageBucket: "fitness-tracker-a32a5.appspot.com",
    messagingSenderId: "1067208300525",
    appId: "1:1067208300525:web:39a89b0c5555dd141a39e4",
    measurementId: "G-3RSC25YFHN"
  }  
};
